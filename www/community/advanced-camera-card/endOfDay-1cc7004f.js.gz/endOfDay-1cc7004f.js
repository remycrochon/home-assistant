import{d4 as r}from"./card-e6d61164.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
