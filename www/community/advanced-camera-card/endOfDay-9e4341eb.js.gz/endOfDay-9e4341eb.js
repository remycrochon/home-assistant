import{dR as r}from"./card-14af3f7e.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
